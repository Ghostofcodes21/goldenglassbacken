const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' })); // Handle images as base64

app.post('/chat', async (req, res) => {
  const { message, image } = req.body;

  // Simple response logic
  let reply = '';
  if (message) reply = `You said: "${message}"`;
  if (image) reply += reply ? ' (and sent an image)' : 'You sent an image!';

  res.json({ reply });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log('✅ Backend running on port ' + port));
